/*----------------Use the database on AWS RDS(recommended)--------------------*/
I uploaded the database into the AWS RDS.
Users can use "ConnectToAWS.php" to connect with AWS RDS in PHP.
Users can connect AWS by using the Workbench, just follow "how to connect with AWS and basic workbench operations.pdf" 
And if users are using Linux, you can follow "how to connect with AWS in Linux.pdf"


/*-----------------------Use the local database-------------------------------*/
If you wanna just create a local database, u can do the following things.
You can use "wework2.2 with E-R diagram(on workbench).mwb" to use the model on workbench.But it's not the newest
Or you can use "weWork.sql" to create a new local database.
And you can fill all the tables by filling files in query_filling, the filling order can be: FillingToCategory.sql, FillingToCity.sql,FillingToUser_detail.sql, FillingToUser.sql,FillingToReview.sql, FillingToJob.sql, FillingToJob_applicant.sql, FillingToPayment_history.sql.


/*------------------------About Mysql Queries---------------------------------*/
There are all kinds of queries with comments for each table. 
If you want to delete something, see the "query_delete".
If you want to insert/add something, see the "query_insert".
If you want to search/get something, see the "query_search".
If you want to update/set something, see the "query_update".

If you want to know how the database is designed, you can see the "Version.txt", "wework database design process.docx", "E-R diagram" and the "wework.sql", there are comments in it.

/*-------------------------------Connect me----------------------------------*/
If there is anything wrong when u try to connect to the AWS RDS or you just need help, pls connect me.
Because the AWS is only free in the 1st year. Some things will be changed later.

Connector: Bo
	   sxyplibo@gmail.com.