/*u can set the payment by the payment_history_id*/
UPDATE `wework`.`payment_history` SET `status`='PENDING' WHERE `id`='1';


/*u maybe want to update the  payment_history by the job_id and  payee user_id or the payee user's email*/
UPDATE `wework`.`payment_history` SET `status`='SUCCESSFUL' WHERE `job_id`='1' and `payee_id`=(
		select `id` from `wework`.`user` where `email`='sxsxsxsxs@gmail.com');
        

/*u maybe want to update the  payment_history by the  payer_id and job_id*/
UPDATE `wework`.`payment_history` SET `status`='FAILING' WHERE `job_id`='1' and `payer_id`='1';