/*review,  Actually I don't think people should change it or the rating*/
UPDATE `wework`.`review` SET `review`='I‘m not very sure should we allow people to change his review?' WHERE `reviewer_id`='2' and`user_id`='1';
/*user_id and reviewer_id are both id in user table*/