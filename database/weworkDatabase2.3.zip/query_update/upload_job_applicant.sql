/*u can change the status or the results when u know both job_id and user_id*/
UPDATE `wework`.`job_applicant` SET `status`='WORKING', `result`='good job!' WHERE `job_id`='2' and`user_id`='1';

/*a harder one, u can track the job_Applicant by poster's id and applicant's id,*/
UPDATE `wework`.`job_applicant` SET `status`='FAILING', `result`='good job!' WHERE `user_id`='1' and `job_id`=(
	select `id` from `wework`.`job` where `poster_id`='1'
) ;


/*in safe update mode, u  must get the id by useing search query  and then use this id to update it*/
/*a harder one, u can track the job_Applicant by poster's email and applicant's email,*/
UPDATE `wework`.`job_applicant` SET `status`='SUCCESSFUL', `result`='good job!' WHERE `job_id`=(
	select `id` from `wework`.`job` where `poster_id`=(
		select `id` from `wework`.`user` where `email`='sxyyyy@gmail.com')
) and`user_id`=(
		select `id` from `wework`.`user` where `email`='sxsxsxsxs@gmail.com');
        
