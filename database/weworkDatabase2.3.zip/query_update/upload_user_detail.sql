/*u can set the user_detail by the user_detail_id*/
UPDATE `wework`.`user_detail` SET `first_name`='Bo', `last_name`='LI', `phone`='3152528222', `street`='bluestreet' WHERE `id`='2';

/*u maybe want to update the user_Detail by the user_id or the user's email*/

UPDATE `wework`.`user_detail` SET `first_name`='Bo', `last_name`='LI', `phone`='3152528222', `street`='test' WHERE `id`=(
		select `user_detail_id` from `wework`.`user` where `email`='sxsxsxsxs@gmail.com');
        

UPDATE `wework`.`user_detail` SET `first_name`='Bo', `last_name`='LI', `phone`='3152528222', `street`='thurber' WHERE `id`=(
		select `user_detail_id` from `wework`.`user` where `id`='1');