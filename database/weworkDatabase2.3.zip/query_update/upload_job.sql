UPDATE `wework`.`job` SET `city_id`='1', `category_id`='1', `status`='CLOSED' WHERE `id`='1';
/*for job table, when a job is created, id、poster_id、job_detail_id are fixed, u can only change the city_id or the category_id*/

/*in safe update mode, u  must get the id by useing search query  and then use this id to update it*/
