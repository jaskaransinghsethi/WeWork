UPDATE `wework`.`user` SET `balance`='25', `rating`='9' WHERE `id`='1';

/* at most time we can get the user by its id or email */
UPDATE `wework`.`user` SET `balance`='25', `rating`='10' WHERE `email`='sxsxsxsxs@gmail.com';

/* !-----remeber dont change its id or user_detail_id*/