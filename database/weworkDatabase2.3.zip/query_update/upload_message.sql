UPDATE `wework`.`message`
SET
`sender_id` = '2',
`reciever_id` = '1',
`message` = 'hello this is update operation'
WHERE `id` = '1';