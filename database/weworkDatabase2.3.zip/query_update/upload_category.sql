UPDATE `wework`.`category` SET `description`='hardware research----I like it !' WHERE `id`='1';
/*for most time we only change description, but its fine to change category */