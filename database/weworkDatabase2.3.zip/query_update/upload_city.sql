/*update by id*/
UPDATE `wework`.`city` SET `city`='New City' WHERE `id`='2';


UPDATE `wework`.`city` SET `city`='New City' WHERE `city`='Syracuse' and `state`='NY';
/*you may cannot do this in safe update mode, if so  u can get the id by useing search query  and then use this id to update it*/
/*the only chance u will update a city is the city had a new name, like this example, we call Syracuse as New City now */