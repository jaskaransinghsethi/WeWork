
INSERT INTO `wework`.`user`( `email`, `password`, `rating`, `user_detail_id`) VALUES
( 'bob@gmail.com', 'bob', 2, 1),
( 'akshay@gmail.com', 'akshay', 5.0, 2),
( 'v@gmail.com', 'v', 2, 3),
( 'malhar@gmail.com', 'malhar', 5, 4),
( 'jaskaran@gmail.com', 'jaskaran', 4.3, 5),
( 'nidhi@gmail.com', 'nidhi', 3, 6),
( 'akshay2@gmail.com', 'akshay2',  7.5, 7),
( 'khushboo@gmail.com', 'khushboo',  8.6, 8),
( 'akshay3@gmail.com', 'akshay3',  7.5, 9),/*why so many akshay here? triplets? quadruplet?*/
( 'malhar2@gmail.com', 'malhar2', 8.9, 10),
( 'nidhi.junk55@gmail.com', 'nidhiIV',  1.2, 11),/*lol cool*/
( 'manushi@gmail.com', 'manushi', 9.2, 12),
( 'vaibhav@gmail.com', 'vaibhav', 7, 13),
( 'jaskaran2@gmail.com', 'jaskaran2',  8.8, 14),
( 'malhar3@gmail.com', 'malhar3', 9.9, 15),/*triplets!*/
( 'karan@karan.com', 'karan',  1.1, 16),
( 'john@gmail.com', 'john',  9.9, 17);
