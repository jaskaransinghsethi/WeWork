INSERT INTO `wework`.`payment_history` (`payee_id`, `payer_id`, `job_id`, `amount`, `transaction_id`) VALUES ('3', '1', '1', '10', 'FHSDJA6125710');
INSERT INTO `wework`.`payment_history` (`payee_id`, `payer_id`, `job_id`, `amount`, `transaction_id`) VALUES ('7', '5', '6', '243', 'FHSDJA6125711');
INSERT INTO `wework`.`payment_history` (`payee_id`, `payer_id`, `job_id`, `amount`, `transaction_id`) VALUES ('16', '5', '5', '21', 'FHSDJA6125712');
INSERT INTO `wework`.`payment_history` (`payee_id`, `payer_id`, `job_id`, `amount`, `transaction_id`) VALUES ('8', '5', '7', '100', 'FHSDJA6125713');
