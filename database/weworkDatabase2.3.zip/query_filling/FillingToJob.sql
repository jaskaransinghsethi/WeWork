INSERT INTO `wework`.`job` (`poster_id`,`title`, `description`,  `city_id`,  `wage`) VALUES ('1', 'Math Homework!', 'This is just a math homework in senior school, can you help me to solve it?',1 ,  '10');
INSERT INTO `wework`.`job` (`poster_id`,`title`, `description`,  `city_id`,  `wage`) VALUES ('2', 'Borrow a bicycle!', 'I wanna borrow a bicycle today, anyone help?', 2, '10');
INSERT INTO `wework`.`job` (`poster_id`,`title`, `description`,  `city_id`,  `wage`) VALUES ('3', 'How to choose a new phone?', 'I want to buy a new telephone, is there any suggestion?', 3, '124');
INSERT INTO `wework`.`job` (`poster_id`,`title`, `description`,  `city_id`,  `wage`) VALUES ('4', 'Bring My Coffee', 'Can anyone help me to buy a starbucks? I\'m in the library and working on the final project!', 2,  '345');
INSERT INTO `wework`.`job` (`poster_id`,`title`, `description`,  `city_id`,  `wage`) VALUES ('5', 'Lonely gourmet', 'I have made many desserts. Does anyone want to taste it?', 59,  '21');
INSERT INTO `wework`.`job` (`poster_id`,`title`, `description`,  `city_id`,  `wage`) VALUES ('5', 'Move house!', 'I need 3 people to help me move all the things, we can talk the details later.', 59,  '243');
INSERT INTO `wework`.`job` (`poster_id`,`title`, `description`,  `city_id`,  `wage`) VALUES ('5', 'Sing', 'Sing a song, if it\'s good, 100 is urs!', 59,  '100');
INSERT INTO `wework`.`job` (`poster_id`,`title`, `description`,  `city_id`,  `wage`) VALUES ('5', 'Debug in C++', 'Is there anyone good at C++? I really need a person who can help me find the bug in my code.',59,  '1000');
INSERT INTO `wework`.`job` (`poster_id`,`title`, `description`,  `city_id`,  `wage`) VALUES ('5', 'Need a seat in the library', 'I really need place to sit here! The finals are urgent!',59,  '200');
