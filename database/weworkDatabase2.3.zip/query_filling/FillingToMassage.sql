INSERT INTO `wework`.`message` (`sender_id`,`reciever_id`,`message`)VALUES
('1', '2',  'hi'),
( '1', '2',  'hi'),
( '3', '2', 'hi'),
( '4', '5', 'hello'),
( '5', '16', 'hi'),
( '5', '16', 'hello');