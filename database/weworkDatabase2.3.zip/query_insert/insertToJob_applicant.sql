
INSERT INTO `wework`.`job_applicant` (`job_id`, `user_id`, `result`) VALUES ('1', '1', 'bad job');

/*the job_id and user_id must already exist, the status is an enum class contains 'WORKINGING','FAILING','SUCCESSFUL',  the default is "WORKING"*/
