INSERT INTO `wework`.`user_detail` (`first_name`, `last_name`, `phone`, `street`) VALUES ('Bob', 'Lird', '3159411808', 'Thurber st');
/*email is in user table  to makesure when u sign up a new account u at least need input an email account*/
/*THERE ARE A LOT OF THINGS CAN BE INSERTED HERE*/
/*
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `date_of_birth` varchar(45) DEFAULT NULL, 
  `nationality` varchar(128) DEFAULT NULL,
  `gender` enum('MALE','FEMALE','I CHOOSE NOT TO DISCLOSE') DEFAULT 'I CHOOSE NOT TO DISCLOSE',
  
  `phone` bigint(32) DEFAULT NULL,	
  `street` varchar(256) DEFAULT NULL,
  `apartment` varchar(256) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `zipcode` int(11) DEFAULT NULL,
  
  `career_objective` varchar(1024) DEFAULT NULL,
  `work_history` varchar(1024) DEFAULT NULL,
  `educational_background` varchar(1024) DEFAULT NULL,
  `skills` varchar(256) DEFAULT NULL,
  `languages` varchar(256) DEFAULT NULL,
*/

INSERT INTO `wework`.`user_detail`  ( `first_name`, `last_name`, `date_of_birth`, `nationality`, `gender`, `street`, `apartment`, `city_id`, `zipcode`, `skills`, `languages`) VALUES
( 'akshay', 'jagtap', '1995-10-04', 'indian', 'MALE', '555 col', 'apt 2', 1, 13210, 'cpp', 'english'),
( 'v', 'a', '1995-09-09', 'kubasd', 'MALE', 'aksjbf', 'lkausbf', 1, 0, 'asfohu', 'asofu'),
( 'Malhar', 'Ujawane', '1995-08-28', 'Indian', 'MALE', '1023 Ack ', 'Ave', 1,  13210, 'Design', 'Hindi'),
( 'Jaskaran', 'S', '1989-08-08', 'INd', 'MALE', '128', 'aksjfd', 12,  0, 'asfa', 'asf'),
( 'Nidhi', 'Prakash', '1995-04-24', 'Indian', 'FEMALE', '543 columbus ave', '', 1, 13210, 'kbjlihkyouyiyigi', 'English and Hindi'),
( 'akshay', 'jagtap', '1995-04-10', 'indian', 'MALE', '555 col ave', 'apt 2', 12, 13210, 'cpp', 'english'),
( 'Khushboo', 'K', '1995-08-08', 'Indian', 'FEMALE', '14q2jonsf', 'zwsrsawt', 12, 123456, 'sra', 'ZSFSZF'),
( 'Akshay', 'Jagtap', '1995-04-10', 'Indian', 'MALE', '555 Columbus Ave', 'Apt 2', 2, 13210, 'Cpp Java Sql', 'English'),
( 'Malhar', 'Ujawane', '1995-08-27', 'Indian', 'MALE', '1023 Ackerman Ave', 'Apt 2', 2, 13210, 'Front End', 'English'),
( 'Nidhi', 'Prakash', '1995-05-24', 'Indian', 'FEMALE', '543 Columbus Ave', '', 2, 13210, 'Java Sql', 'English Kannada'),
( 'Manushi', 'Sheth', '1995-09-19', 'Indian', 'FEMALE', '543 Columbus Ave', '', 2, 13210, 'Cpp Java', 'English'),
( 'Vaibhav', 'Kumar', '1989-05-06', 'Indian', 'MALE', '1011 East Genesse', '', 2, 13210, 'Dbms sql java', 'English Hindi'),
( 'Jaskaran', 'Sethi', '1995-11-11', 'Indian', 'MALE', '1101 E Genesse', '', 2, 13210, 'PHP', 'English'),
( 'Malhar', 'Ujawane', '1995-08-28', 'Indian', 'MALE', '1023', 'Ack', 12, 13210, 'ABC', 'English'),
( 'Karan', 'K', '0000-00-00', 'Indian', 'MALE', 'Lancester', 'ABC', 2,  13210, 'Developer', 'English'),
( 'John', 'Doe', '1995-08-08', 'American', 'MALE', 'Ackerman', 'Avenue', 2, 13210, 'ABC', 'English');