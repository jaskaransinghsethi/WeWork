INSERT INTO `wework`.`review` (`user_id`, `reviewer_id`, `rating`, `review`) VALUES ('1', '2', '10', 'hahaha');
/*the user_id must be not the reviewer_id, the rating must be an integer between 0-10.*/