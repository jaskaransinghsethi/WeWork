/*make sure the sender_id and reciever_id are already created.*/
INSERT INTO `wework`.`message` (`sender_id`,`reciever_id`,`message`) VALUES( '1', '2', 'hi');
