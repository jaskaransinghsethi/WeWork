INSERT INTO `wework`.`job` (`poster_id`,`category_id`, `city_id`,`wage`) VALUES ('1', '1', '1','50');
/*the posterid(user_id), job_detail_id must already exist, the job_detail_id must be unique*/
/*the city_id and category_id can be NULL  
like below:        */
/*INSERT INTO `wework`.`job` (`poster_id`, `wage`) VALUES ('1',  '50');*/

/*There is a status here, it's an enum class contains 'AVAILABLE','CLOSED', the default value is 'AVAILABLE'*/