INSERT INTO `wework`.`payment_history` (`payee_id`, `payer_id`, `job_id`, `amount`, `transaction_id`) VALUES ('1', '2', '1', '50', 'SADADDSAD121212');

/*the userid must already exist, default status is  'PENDING', it's an enum class about'PENDING','FAILING','SUCCESSFUL' */