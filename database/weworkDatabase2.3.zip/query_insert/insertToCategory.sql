/*u can just add category or them all*/
INSERT INTO `wework`.`category` (`category`, `description`) VALUES ('Accounting/Finance', 'Accounting/Finance\'s description');
