/*please add the city and  its state at same time*/
INSERT INTO `wework`.`city` (`city`, `state`) VALUES ('Syracuse', 'NY');
