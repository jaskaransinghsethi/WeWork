
/*got rating by user_id and reviewer_id*/
select `rating` from `wework`.`review` where `user_id`='1' and `reviewer_id`='3';
/*got review by user_id and reviewer_id*/
select `review` from `wework`.`review` where `user_id`='1' and `reviewer_id`='3';


/*got rating and review by user_id and reviewer_id*/
select `rating`,`review` from `wework`.`review` where `user_id`='1' and `reviewer_id`='3';