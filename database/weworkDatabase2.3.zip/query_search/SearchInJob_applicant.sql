/*got the status and result by specific job_id and user_id*/
select `status` from `wework`.`job_applicant` where `job_id`='2' and `user_id`='1';
select `result` from `wework`.`job_applicant` where `job_id`='2' and `user_id`='1';

/*get all the JOB_ID when userid=1 and the JOB is successful*/
select `job_id` from `wework`.`payment_history` where `user_id`='1' and `status`='SUCCESSFUL';/*0 means pending, 1 means successful, 2 means failed*/

/*get all the JOB_ID and result when userid=1 and the JOB is successful*/
select `job_id`,`result` from `wework`.`payment_history` where `user_id`='1' and `status`='SUCCESSFUL';/*0 means pending, 1 means successful, 2 means failed*/

/*got the status and result by specific job_id and user_email*/
select `status` from `wework`.`job_applicant` where `job_id`='2' and `user_id`=(
		select `id` from `wework`.`user` where `email`='sxsxsxsxs@gmail.com');

select `result` from `wework`.`job_applicant` where `job_id`='2' and `user_id`=(
		select `id` from `wework`.`user` where `email`='sxsxsxsxs@gmail.com');



