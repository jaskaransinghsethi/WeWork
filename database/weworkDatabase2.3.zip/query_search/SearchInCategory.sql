/*u can execute them one by one*/
/*got all category_id in this table*/
select `id` from `wework`.`category`;


/*got category_id for Accounting/Finance*/
select `id` from `wework`.`category` where `category`='Accounting/Finance';


/*got description for Accounting/Finance*/
select `description` from `wework`.`category` where `category`='Accounting/Finance';

/*got category and description by id*/
select `category`,`description`  from `wework`.`category` where `id`='1';