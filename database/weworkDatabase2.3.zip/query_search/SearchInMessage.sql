SELECT `message`.`id`,
    `message`.`sender_id`,
    `message`.`reciever_id`,
    `message`.`time`,
    `message`.`message`
FROM `wework`.`message`
where `id`='1';