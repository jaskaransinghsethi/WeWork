
/*got payment_id  by payee's user_id*/
select `id` from `wework`.`payment_history` where `payee_id`='1';

/*got create_time  by payer's user_id*/
select `create_time` from `wework`.`payment_history` where `payer_id`='1';

/*got amount  by payee user_id*/
select `amount` from `wework`.`payment_history` where `payee_id`='1';

/*got status  by payee user_id*/
select `status` from `wework`.`payment_history` where `payee_id`='1';

/*get all the amount which is payee userid=1 and the payment is successful*/
select `amount` from `wework`.`payment_history` where `payee_id`='1' and `status`='SUCCESSFUL';/*0 means pending, 1 means successful, 2 means failed*/

/*get all the amount which is payee userid=1 and the payment is pending*/
select `amount` from `wework`.`payment_history` where `payee_id`='1' and `status`='PENDING';/*0 means pending, 1 means successful, 2 means failed*/

/*get all the amount which is payee's userid=1 and the payment is after 2018-04-20 15:32:57*/
select `amount` from `wework`.`payment_history` where `payee_id`='1' and `create_time`>'2018-04-20 15:32:57';/*0 means pending, 1 means successful, 2 means failed*/