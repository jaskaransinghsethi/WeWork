
/*got first_name  by user_detail_id*/
select `first_name` from `wework`.`user_detail` where `id`='1';

/*got last_name  by user_detail_id*/
select `last_name` from `wework`.`user_detail` where `id`='1';

/*got phone  by user_detail_id*/
select `phone` from `wework`.`user_detail` where `id`='1';

/*got address  by user_detail_id*/
select `work_history` from `wework`.`user_detail` where `id`='1';

/*and u can got all the users id who named Bo Li like below:*/
select `id` from `wework`.`user_detail` where `first_name`='Bo' and `last_name`='Li';

/*get user_detail_id from user table*/

select `work_history` from `wework`.`user_detail` where `id`=(
	select `user_detail_id` from `wework`.`user` where `email`='ned@gmail.com'
);