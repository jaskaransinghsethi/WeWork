/*u can execute them one by one*/
/*GET ALL AVAILABLE JOBS*/
select `id` from `wework`.`job` where `status`='AVAILABLE'; 

/*get the id by poster_id*/
select `id` from `wework`.`job` where `poster_id`='1'; 

/*get the poster_id by job_id*/
select `poster_id` from `wework`.`job` where `id`='2'; 

/*got poster_id posted by job_id(2) or poster_id*/
select `poster_id` from `wework`.`job` where `id`='2'; 

/*got city_id posted by job_id(2) or poster_id*/
select `city_id` from `wework`.`job` where `id`='2'; 
select `city_id` from `wework`.`job` where `poster_id`='1'; 

/*got category_id posted by job_id(2) or poster_id*/
select `category_id` from `wework`.`job` where `id`='2'; 
select `category_id` from `wework`.`job` where `poster_id`='1'; 

