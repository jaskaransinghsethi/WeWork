/*u can execute them one by one*/
/*got all city_id in state NY*/
select `id` from `wework`.`city` where `state`='NY';


/*got cities in state NY*/
select `city` from `wework`.`city` where `state`='NY';


/*got state by city*/
select `state` from `wework`.`city` where `city`='Syracuse';
        

/*got city_id in state NY in Syracuse*/
select `id` from `wework`.`city` where `state`='NY' and `city`='Syracuse';