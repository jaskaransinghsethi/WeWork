/*got email  by user_id*/
select `email` from `wework`.`user` where `id`='1';

/*got password  by user_id*/
select `password` from `wework`.`user` where `id`='1';

/*got balance  by user_id*/
select `balance` from `wework`.`user` where `id`='1';

/*got rating  by user_id*/
select `rating` from `wework`.`user` where `id`='1';

/*got user_detail_id  by user_id*/
select `user_detail_id` from `wework`.`user` where `id`='1';

/*and u can got them by email too, like below*/
select `password` from `wework`.`user` where `email`='sxsxxsxsxsxs@gmail.com';

/*and u can got the users whose rating is larger than 8.0*/
select `id` from `wework`.`user` where `rating`>'8.0';