/*at most time we just delete the lines which meet the conditions after WHERE*/
/*u cannot delete it when it's used in other table*/
/*so make sure u deleted its user information in user table first*/
Delete from `wework`.`user_detail` where `id`='1';

/*you can delete the user_Detail with the user's email or user's id*/
Delete from `wework`.`user_detail` where `id`=(
	select `user_detail_id` from `wework`.`user` where `email`='ned@gmail.com'
);

Delete from `wework`.`user_detail` where `id`=(
	select `user_detail_id` from `wework`.`user` where `id`='1'
);
Delete from `wework`.`user_detail` where `id`>'1';