/*at most time we just delete the lines which meet the conditions after WHERE*/
/*u cannot delete it when it's used in other table*/
/*make sure u delete all this users information in payment_history table and review table*/
/*you can try to delete user based on other things, but only the email and id are unique, so they are recommended. */
Delete from `wework`.`user` where `email`='sxsxsxs@gmail.com';
Delete from `wework`.`user` where `id`='1';