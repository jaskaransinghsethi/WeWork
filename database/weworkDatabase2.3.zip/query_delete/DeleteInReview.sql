/*at most time we just delete the lines which meet the conditions after WHERE*/
/*u cannot delete it when it's used in other table*/
Delete from `wework`.`review` where `user_id`='1';/*delete all the reviews user_id1 got*/
Delete from `wework`.`review` where `reviewer_id`='1';/*delete all the reviews user_id1 made*/
Delete from `wework`.`review` where `reviewer_id`='2' and `user_id`='1';/*delete the reviews user2 made to user1*/