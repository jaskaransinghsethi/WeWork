/*at most time we just delete the lines which meet the conditions after WHERE*/
/*u cannot delete it when it's used in other table*/
/*before delete it  make sure there is no this job in job_applicant table, otherwise u need delete it from job_applicant table 1st*/
Delete from `wework`.`job` where `id`='2';
