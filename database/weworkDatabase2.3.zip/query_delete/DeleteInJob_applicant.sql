/*at most time we just delete the lines which meet the conditions after WHERE*/
/*u cannot delete it when it's used in other table*/
Delete from `wework`.`job_applicant` where `job_id`='2';/*delete all the pair whose job is 2*/
Delete from `wework`.`job_applicant` where `user_id`='1';/*delete all the pair whose user is 1*/
