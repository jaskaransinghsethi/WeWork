/*at most time we just delete the lines which meet the conditions after WHERE*/
/*u cannot delete it when it's used in other table*/
Delete from `wework`.`category` where `category`='Accounting/Finance';