/*at most time we just delete the lines which meet the conditions after WHERE*/
/*u cannot delete it when it's used in other table*/
Delete from `wework`.`payment_history` where `user_id`='1';/*delete user1's all payment history*/
Delete from `wework`.`payment_history` where `id`='1' and `user_id`='1';/*delete user1's one payment history whose id =1*/

Delete from `wework`.`payment_history` where `job_id`='1' and `user_id`='1';/*delete user1's one payment history that he got from job1*/
Delete from `wework`.`payment_history` where `transaction_id`='12133121311' ;/*delete the payment history whose transaction_id is 12133121311, transaction_id is unique*/