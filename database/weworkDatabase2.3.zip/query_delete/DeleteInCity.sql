/*at most time we just delete the lines which meet the conditions after WHERE*/
/*u cannot delete it when it's used in other table*/

Delete from `wework`.`city` where `city`='Syracuse';
Delete from `wework`.`city` where `state`='NY';/*delete all the cities in NY*/
