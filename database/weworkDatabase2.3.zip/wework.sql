DROP SCHEMA IF EXISTS `wework`;

CREATE SCHEMA `wework`;

use `wework`;

SET FOREIGN_KEY_CHECKS = 0;

/*------------------city: 1 to m job, many jobs can be posted in one city---------------------*/
/*------------------the website is just open for the cities inside the table for now---------------*/
DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(256) NOT NULL,/*no city  only state is not allowed*/
  `state` varchar(128) NOT NULL,/*every city must be in a state, states are unique*/
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


/*------------------category: 1 to m job, many jobs can have one category ---------------------*/
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category`  varchar(256) DEFAULT NULL unique,	/*category must be unique*/
  `description` varchar(20000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*------------------for each user  there must be a user_detail, even an empty detail---------------------*/
/*------------------1 to 1 relationship---------------------*/
DROP TABLE IF EXISTS `user_detail`;
CREATE TABLE `user_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `date_of_birth` varchar(45) DEFAULT NULL, /*This can be varchar, datetime, int. With varchar, there is no need for date-to-string conversion in the background, which is compatible with multiple database switches. You need to write your own calculation time algorithm, but it is only good to display and search.*/
  `nationality` varchar(128) DEFAULT NULL,
  `gender` enum('MALE','FEMALE','I CHOOSE NOT TO DISCLOSE') DEFAULT 'I CHOOSE NOT TO DISCLOSE',
  
  `phone` bigint(32) DEFAULT NULL,				/*for some special telephone number, actually string is fine but int is quicker */
  `street` varchar(256) DEFAULT NULL,
  `apartment` varchar(256) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `zipcode` int(11) DEFAULT NULL,
  
  `career_objective` varchar(1024) DEFAULT NULL,
  `work_history` varchar(1024) DEFAULT NULL,
  `educational_background` varchar(1024) DEFAULT NULL,
  `skills` varchar(256) DEFAULT NULL,
  `languages` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  
  KEY `FK_USERCITY_idx` (`city_id`),  
  CONSTRAINT `FK_USERCITY`   FOREIGN KEY (`city_id`) 
  REFERENCES `city` (`id`)   ON DELETE NO ACTION ON UPDATE NO ACTION
  
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;



/*------------------user: 1 to m payment_history,for each user  there may be many payment_history ---------------------*/
/*------------------user: m to m job_applicant, each user can have many jobs, each jobs can have many applicants ----------------------*/
/*------------------user: 1 to m job, one poster may post many jobs, each job must have one poster ---------------------*/
/*------------------user: 1 to 1 user_detail, for each user  there must be a user_detail, even an empty detail ---------------------*/

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(45) NOT NULL unique,/*must have an email and must be unique*/
  `password` varchar(45) NOT NULL,  /*must have a password*/
  `balance` int(11) DEFAULT 100,    /*start with 100 coins*/
  `rating` double(11,1) DEFAULT NULL,/*average of all rating for this user, restore all the ratings and comments in the review table;*/
  `user_detail_id` int(11) DEFAULT NULL unique,/*every user has differet user_detail space*/
  PRIMARY KEY (`id`),
        
  KEY `FK_USERDETAIL_idx` (`user_detail_id`),
  CONSTRAINT `FK_USERDETAIL` FOREIGN KEY (`user_detail_id`) 
  REFERENCES `user_detail` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION /*if a user is deleted, the user_detail for this user should be deleted*/
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


/*-------------------------job-applicant pair(many to many relationship)-------------------------------*/
DROP TABLE IF EXISTS `review`;
CREATE TABLE `review` (
  `user_id` int(11) NOT NULL,  
  `reviewer_id` int(11) NOT NULL,/*make sure reviewerid!=userid in one row */
  `rating` int(11) DEFAULT NULL,/*rating should be no more than 10, no less than 0 */
  `review` varchar(20000) DEFAULT NULL,/*THE result */  
  PRIMARY KEY (`reviewer_id`,`user_id`),
  
  KEY `FK_REVIEWER_idx` (`reviewer_id`),  
  CONSTRAINT `FK_REVIEWER` FOREIGN KEY (`reviewer_id`) 
  REFERENCES `user` (`id`) 
  ON DELETE NO ACTION ON UPDATE NO ACTION,
  
  KEY `FK_USERRATING_idx` (`user_id`),  
  CONSTRAINT `FK_USERRATING` FOREIGN KEY (`user_id`) 
  REFERENCES `user` (`id`) 
  ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*------------------job: m to m job_user, each user can have many jobs, each jobs can have many applicants ---------------------*/
/*------------------job: m to 1 city, each city can have many jobs ---------------------*/
/*------------------job: m to 1 user, each job must have one poster, one poster can post many jobs ---------------------*/
/*------------------job: 1 to 1 job_detail, each job must have one detail, even it's empty ---------------------*/
DROP TABLE IF EXISTS `job`;
CREATE TABLE `job` (

  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poster_id` int(11) NOT NULL,  			/* each job must have a poster */
  `create_time` timestamp DEFAULT now(),
  `title` varchar(128) DEFAULT NULL,
  `description` varchar(20000) DEFAULT NULL,
  `category_id`  int(11) DEFAULT NULL,		/* default means search from All category */  
  `status` enum('AVAILABLE','CLOSED') DEFAULT 'AVAILABLE',
  `type` varchar(128) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,	 		/* default means search from all cities */
  `comments` varchar(1024) DEFAULT NULL,
  `wage` int(20) DEFAULT NULL,         /*our coin will be all integers, this is wage for this job*/  
  
  PRIMARY KEY (`id`),
  
  KEY `FK_USER_idx` (`poster_id`),  
  CONSTRAINT `FK_USER`   FOREIGN KEY (`poster_id`) 
  REFERENCES `user` (`id`)   ON DELETE NO ACTION ON UPDATE NO ACTION, 
   
  KEY `FK_CITY_idx` (`city_id`),  
  CONSTRAINT `FK_CITY`   FOREIGN KEY (`city_id`) 
  REFERENCES `city` (`id`)   ON DELETE NO ACTION ON UPDATE NO ACTION,
  
  KEY `FK_CATEGORY_idx` (`category_id`),  
  CONSTRAINT `FK_CATEGORY`   FOREIGN KEY (`category_id`) 
  REFERENCES `category` (`id`)   ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

/*-------------------------job-applicant pair(many to many relationship)-------------------------------*/
DROP TABLE IF EXISTS `job_applicant`;
CREATE TABLE `job_applicant` (
  `job_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,  
  `status` enum('WORKINGING','FAILING','SUCCESSFUL') DEFAULT 'WORKINGING',
  `result` varchar(128) DEFAULT NULL,/*THE result */
  
  PRIMARY KEY (`job_id`,`user_id`),
  
  KEY `FK_JOB_idx` (`job_id`),  
  CONSTRAINT `FK_JOB` FOREIGN KEY (`job_id`) 
  REFERENCES `job` (`id`) 
  ON DELETE NO ACTION ON UPDATE NO ACTION,
  
  KEY `FK_USER_idx` (`user_id`),  
  CONSTRAINT `FK_USER_idx` FOREIGN KEY (`user_id`) 
  REFERENCES `user` (`id`) 
  ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*------------------for each user  there may be many payment_history---------------------*/
/*------------------many to 1 relationship---------------------*/
DROP TABLE IF EXISTS `payment_history`;
CREATE TABLE `payment_history` (
  `id` int(20) NOT NULL AUTO_INCREMENT,  /* there can be more payments than users*/
  `payee_id` int(11) NOT NULL,           /* the guy who got payment*/
  `payer_id` int(11) NOT NULL,           /* to be honest, when we create a payment for payee, we need create another for payer at the same time*/
  `job_id` int(11) NOT NULL,             
  `create_time` timestamp DEFAULT now(),
  `amount` int(20) DEFAULT NULL,         /*our coin will be all integers*/
  `status` enum('PENDING','FAILING','SUCCESSFUL') DEFAULT 'PENDING',
  `transaction_id` varchar(50) NOT NULL unique,/*THE transaction id for tracking */
  
  PRIMARY KEY (`id`),  
  KEY `FK_PAYEE_idx` (`payee_id`),  
  CONSTRAINT `FK_PAYEE` FOREIGN KEY (`payee_id`) 
  REFERENCES `user` (`id`) 
  ON DELETE NO ACTION ON UPDATE NO ACTION,
  
  KEY `FK_PAYER_idx` (`payer_id`),  
  CONSTRAINT `FK_PAYER` FOREIGN KEY (`payer_id`) 
  REFERENCES `user` (`id`) 
  ON DELETE NO ACTION ON UPDATE NO ACTION,
  
  KEY `FK_PAYMENTJOB_idx` (`job_id`),  
  CONSTRAINT `FK_PAYMENTJOB` FOREIGN KEY (`job_id`) 
  REFERENCES `job` (`id`) 
  ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `reciever_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `message` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_SENDER_idx` (`sender_id`),
  KEY `FK_RECIEVER_idx` (`reciever_id`),
  CONSTRAINT `FK_RECIEVER` FOREIGN KEY (`reciever_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_SENDER` FOREIGN KEY (`sender_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

SET FOREIGN_KEY_CHECKS = 1;
